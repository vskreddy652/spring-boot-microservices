package com.javasampleapproach.sendingmail.mail;

import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component("javasampleapproachMailSender")
public class MailSender {
	
	@Autowired
	JavaMailSender javaMailSender;
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public void sendMail(String from, String to, String subject, String body) {
		
		SimpleMailMessage mail = new SimpleMailMessage();

		mail.setFrom(from);
		mail.setTo(to);
		mail.setSubject(subject);
		mail.setText(body);
		
		try {
		//below
        MimeMessage mm = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mm, true);
        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText("Hello Can <b>you see</b> this", true);
		//above
		
		logger.info("Sending...");
		
		javaMailSender.send(mm);
		
		logger.info("Done!");
		}
		catch(Exception et)
		{
			System.out.println("Exception occurred "+et);
		}
	}
}