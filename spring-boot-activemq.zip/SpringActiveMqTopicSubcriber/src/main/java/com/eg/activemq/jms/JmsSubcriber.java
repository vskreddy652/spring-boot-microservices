package com.eg.activemq.jms;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.eg.activemq.models.Company;


@Component
public class JmsSubcriber {
	
	@JmsListener(destination = "${jsa.activemq.topic}")
	public void receive(Company msg){
		System.out.println("Recieved Message: " + msg);
	}
}
