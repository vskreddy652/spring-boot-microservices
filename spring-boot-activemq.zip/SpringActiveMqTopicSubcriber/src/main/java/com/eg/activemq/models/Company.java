package com.eg.activemq.models;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
 
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
 
@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = Company.class)
public class Company {
    private String naaaaaaaaaaaame;
 
    private List<Product> prrrrrrrrrroducts;
	
    public Company(){
    }
    
    public Company(String name, List<Product> products){
    	this.naaaaaaaaaaaame = name;
    	this.prrrrrrrrrroducts = products;
    }
    
    // name
    public String getName() {
        return naaaaaaaaaaaame;
    }
    
    public void setName(String name) {
        this.naaaaaaaaaaaame = name;
    }
    
    // products
    public void setProducts(List<Product> products){
    	this.prrrrrrrrrroducts = products;
    }
    
    public List<Product> getProducts(){
    	return this.prrrrrrrrrroducts;
    }
 
	/**
	 * 
	 * Show Detail View
	 */
	public String toString(){
		JSONObject jsonInfo = new JSONObject();
		
		try {
			jsonInfo.put("name", this.naaaaaaaaaaaame);
 
			JSONArray productArray = new JSONArray();
			if (this.prrrrrrrrrroducts != null) {
				this.prrrrrrrrrroducts.forEach(product -> {
					JSONObject subJson = new JSONObject();
					try {
						subJson.put("name", product.getName());
					} catch (JSONException e) {}
					
					productArray.put(subJson);
				});
			}
			jsonInfo.put("products", productArray);
		} catch (JSONException e1) {}
		return jsonInfo.toString();
	}
 
}